// JavaScript Document

$(document).ready(function() {
		$('#slider').coinslider({ width: 480, height: 300, delay: 5000, navigation: false, effect: 'rain' });
	});